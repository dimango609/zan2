﻿using System;

class Laptop
{
    public const string DefaultProcessor = "Intel Core i5";
    public const string DefaultRAM = "8GB";
    public const string DefaultHardDrive = "256GB SSD";
    public const double DefaultPrice = 80000.00;
    public const string DefaultModelName = "Asus";
    public virtual void PrintDetails()
    {
        Console.WriteLine($"Model: {DefaultModelName}");
        Console.WriteLine($"Processor: {DefaultProcessor}");
        Console.WriteLine($"RAM: {DefaultRAM}");
        Console.WriteLine($"Hard Drive: {DefaultHardDrive}");
        Console.WriteLine($"Price: ${DefaultPrice}");
    }
}

class SpecificLaptop : Laptop
{
    private string modelName;
    private double price;
    private string processor;
    private string ram;
    private string hardDrive;
    public SpecificLaptop(string modelName, double price, string processor, string ram, string hardDrive)
    {
        this.modelName = modelName;
        this.price = price;
        this.processor = processor;
        this.ram = ram;
        this.hardDrive = hardDrive;
    }
    public override void PrintDetails()
    {
        Console.WriteLine($"Model: {modelName}");
        Console.WriteLine($"Processor: {processor}");
        Console.WriteLine($"RAM: {ram}");
        Console.WriteLine($"Hard Drive: {hardDrive}");
        Console.WriteLine($"Price: {price} (RUB)");
    }
}

class Program
{
    static void Main()
    {
        Console.WriteLine("Введите название ноутбука:");
        string modelName = Console.ReadLine();
        Console.WriteLine("Введите процессор ноутбука:");
        string processor = Console.ReadLine();
        Console.WriteLine("Введите колво оперативной памяти:");
        string ram = Console.ReadLine();
        Console.WriteLine("Введите жесткий диск:");
        string hardDrive = Console.ReadLine();
        double price;
        do
        {
            Console.WriteLine("Введите цену ноутбука в рублях:");
        } while (!double.TryParse(Console.ReadLine(), out price));
        SpecificLaptop userLaptop = new SpecificLaptop(modelName, price, processor, ram, hardDrive);
        userLaptop.PrintDetails();
    }
}