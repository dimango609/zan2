﻿using System;

abstract class Log
{
    public abstract void Debug(string message);
    public abstract void Info(string message);
    public abstract void Warn(string message);
    public abstract void Error(string message);
    public abstract void Crit(string message);
}

class ConsoleLog : Log
{
    public override void Debug(string message)
    {
        Console.ForegroundColor = ConsoleColor.Gray;
        Console.WriteLine($"Debug: {message}");
        Console.ResetColor();
    }

    public override void Info(string message)
    {
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine($"Info: {message}");
        Console.ResetColor();
    }

    public override void Warn(string message)
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine($"Warn: {message}");
        Console.ResetColor();
    }

    public override void Error(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.WriteLine($"Error: {message}");
        Console.ResetColor();
    }

    public override void Crit(string message)
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine($"Critical: {message}");
        Console.ResetColor();
    }
}

class Program
{
    static void Main()
    {
        Log logger = new ConsoleLog();
        logger.Debug("сообщение отладки");
        logger.Info("info");
        logger.Warn("предупреждение");
        logger.Error("сообщение об ошибке");
        logger.Crit("критическая ошибка");
    }
}