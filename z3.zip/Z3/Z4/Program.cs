﻿using System;

namespace Z4
{
    class Encrypter
    {
        public static string Encrypt(string text)
        {
            char[] encryptedText = new char[text.Length];
            for (int i = 0; i < text.Length; i++)
            {
                encryptedText[i] = (char)(text[i] + 1);
            }
            return new string(encryptedText);
        }

        public static string Decrypt(string encryptedText)
        {
            char[] decryptedText = new char[encryptedText.Length];
            for (int i = 0; i < encryptedText.Length; i++)
            {
                decryptedText[i] = (char)(encryptedText[i] - 1);
            }
            return new string(decryptedText);
        }
    }

    class Program
    {
        static void Main()
        {
            string originalText = "Hello";
            string encryptedText = Encrypter.Encrypt(originalText);
            string decryptedText = Encrypter.Decrypt(encryptedText);

            Console.WriteLine($"Исходный текст: {originalText}");
            Console.WriteLine($"Шифрованный текст: {encryptedText}");
            Console.WriteLine($"Дешифрованный текст: {decryptedText}");
        }
    }
}