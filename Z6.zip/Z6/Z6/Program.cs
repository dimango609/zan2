﻿using System;

abstract class Animal
{
    public string Name { get; set; }

    public void SetName(string name)
    {
        Name = name;
    }

    public string GetName()
    {
        return Name;
    }

    public abstract void Eat();
}

class Dog : Animal
{
    public override void Eat()
    {
        Console.WriteLine("Собака ест");
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Введите имя собаки: ");
        string dogName = Console.ReadLine();

        Dog dog = new Dog();
        dog.SetName(dogName);

        Console.WriteLine($"Имя собаки: {dog.GetName()}");
        dog.Eat();
    }
}