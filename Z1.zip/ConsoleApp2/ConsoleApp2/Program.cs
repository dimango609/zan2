﻿using System;

class Money
{
    public int Rubles { get; set; }
    public int Kopecks { get; set; }
    public Money(int rubles, int kopecks)
    {
        Rubles = rubles;
        Kopecks = kopecks;
    }

    public void DisplayAmount()
    {
        Console.WriteLine($"Сумма: {Rubles} руб. {Kopecks:00} коп.");
    }
}

class Good
{
    public string Name { get; set; }
    public Money Price { get; set; }

    public Good(string name, int rubles, int kopecks)
    {
        Name = name;
        Price = new Money(rubles, kopecks);
    }

    public void DecreasePriceByPercentage(double percentage)
    {
        double totalKopecks = Price.Rubles * 100 + Price.Kopecks;
        double newPriceKopecks = totalKopecks * (1 - percentage / 100);
        int newRubles = (int)newPriceKopecks / 100;
        int newKopecks = (int)newPriceKopecks % 100;
        Price.Rubles = newRubles;
        Price.Kopecks = newKopecks;
    }

    public void DisplayGoodInfo()
    {
        Console.WriteLine($"Товар: {Name}, Цена: {Price.Rubles} руб. {Price.Kopecks:00} коп.");
    }
}

class Program
{
    static void Main()
    {
        Money money1 = new Money(150, 75);
        money1.DisplayAmount();

        Good good1 = new Good("Товар 1", 200, 50);
        good1.DisplayGoodInfo();
        good1.DecreasePriceByPercentage(10); // Уменьшение цены на 10%
        good1.DisplayGoodInfo();
    }
}