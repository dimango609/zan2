﻿using System;

class Person
{
    public string Name { get; set; }

    public Person(string name)
    {
        Name = name;
    }

    ~Person()
    {
        Name = string.Empty;
    }

    public override string ToString()
    {
        return $"Name: {Name}";
    }
}

class Program
{
    static void Main()
    {
        Person[] people = new Person[3];

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"Имя  персоны? {i + 1}:");
         
            string name = Console.ReadLine();
            people[i] = new Person(name);
        }

        Console.WriteLine("People:");
        foreach (Person person in people)
        {
            Console.WriteLine(person.ToString());
        }
    }
}